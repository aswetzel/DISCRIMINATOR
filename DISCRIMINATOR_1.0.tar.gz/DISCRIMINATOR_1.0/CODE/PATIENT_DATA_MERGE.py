# load required python modules
import os, sys, networkx
from collections import defaultdict
from intervaltree import Interval, IntervalTree
from progress.bar import Bar

if len(sys.argv) != 2:
    print 'PATIENT_DATA_MERGE.py <COHORT FILE>'
    sys.exit(2)

# Set Default Merging Distance
MERGEPARAM=30000

try:
 # Read Cohort File; Create MERGED File
 PATIENT=open(sys.argv[1].strip(),'r').readlines()
 PFILE = sys.argv[1].strip().split('/')[-1:]
 
 # Create MERGED File if not already exists
 MERGED = sys.argv[1].strip().replace('.txt','_MERGED.txt').replace('/SOURCE_DATA/COHORTS/','/OUTPUT/')
 if os.path.isfile(MERGED): 
    print '   MERGED FILE ALREADY EXISTS: '+MERGED.split('/')[-1]; sys.exit()
 else: 
    PATIENT_MERGED=open(sys.argv[1].strip().replace('.txt','_MERGED.txt').replace('/SOURCE_DATA/COHORTS/','/OUTPUT/'),'w')

 # Read 50kb SegDups Cluster File to SegDup Dictionary with CHR as Key; Region as Value
 PATH = os.path.dirname(os.path.realpath(__file__)).replace('/CODE','')
 SEGDUPS=open(PATH+'/CODE/DATA/50kbsegdups.bed','r').readlines()
 SEGDUP_DICT=defaultdict(list)
 for SD in SEGDUPS:
    CHR_NAME=SD.strip().split('\t')[0]
    START=SD.strip().split('\t')[1]
    END=SD.strip().split('\t')[2]
    SEGDUP_DICT[CHR_NAME].append([START,END])

 # Determine which column has Sample, CNV, Direction
 HEADERS=[pat.strip() for pat in PATIENT[0].split('\t')]
 SAMPLE=HEADERS.index('Sample')
 REGION_L=HEADERS.index('Chromosome Region')
 EVENT=HEADERS.index('Event')

 # For Each Line of Cohort File
    # Split Line into List
    # Get PatientID, Chrom, Start, End
    # Standardize Event as "LOSS" or "GAIN"
    # Add Data to PATIENT_DATA dictionary with PatientID as key; [CHROM, START, END, DIR] as Value
 PATIENT_DATA=defaultdict(list)
 ctr=1
 FAIL=[]
 for k in PATIENT[1:]:
    ctr+=1
    if len(k.strip().split('\t')) != 3: FAIL.append(ctr)
    else: 
      try:
        tmp=k.strip().split('\t')
        CHR_NAME=tmp[REGION_L].strip().split(':')[0].replace('"','').strip()
        START=tmp[REGION_L].strip().split(':')[1].replace(',','').replace('"','').split('-')[0]
        END=tmp[REGION_L].strip().split(':')[1].replace(',','').replace('"','').split('-')[1]
        if 'Gain' in tmp[EVENT].strip(): tmp[EVENT]='GAIN'
        elif 'Loss' in tmp[EVENT].strip(): tmp[EVENT]='LOSS'
        else: FAIL.append(ctr)
        DATA=[CHR_NAME,START,END,tmp[EVENT].strip()]
        PATIENT_DATA[tmp[0].strip()].append(DATA)
      except IndexError: 
        FAIL.append(ctr)
 
 # Quit if Incorrectly Formatted Lines of Input File
 if len(FAIL) > 20:
    print "\n",repr(len(FAIL))+" LINES OF COHORT FILE",PFILE,"HAVE INCORRECT FORMATTING"
    sys.exit()
 elif len(FAIL) > 0:
    print "\n","THE FOLLOWING LINES OF COHORT FILE",PFILE,"HAVE INCORRECT FORMATTING:",FAIL
    sys.exit()

 # Create PATIENT_CHR Dictionary
 # Loop through patient's CNVs and add each interval to PATIENT_CHR dictionary with CHROM as Key; [START, END, DIR] as Value
 def make_chr(l1):
    PATIENT_CHR=defaultdict(list)
    for i in l1: PATIENT_CHR[i[0].strip()].append(i[1:])
    return PATIENT_CHR

 # Create PATIENT_STATUS Dictionary
 # Loop through patient's CNVs for specified CHROM and add each interval to PATIENT_STATUS dictionary with DIR as Key; [START, END] as Value
 def gain_loss(l2):
    PATIENT_STATUS=defaultdict(list)
    for k1 in l2: PATIENT_STATUS[k1[-1]].append(k1[0:2])
    return PATIENT_STATUS

 # Used to flip CNVs: [A, B] to [B, A]
 def pairs(lst):
    i = iter(lst)
    first = prev = item = i.next()
    for item in i:
        yield prev, item
        prev = item
    yield item, first

 # Function to Flatten Lists
 def flatten(ALL):
    FLAT=[]
    for sublist in ALL:
        if type(sublist) == str: FLAT.append(sublist)
        if type(sublist) == list: 
            if len(sublist) >1: 
                for item in sublist: FLAT.append(item)
            else: FLAT.append(sublist)
    return FLAT

 # Loop through patients' CNVs for specified CHROM+DIR
    # If 1 CNV: Add CNVs to SINGLES1 List
    # If 2+ CNVs: Add CNVs to ALLREGION List
        # If Distance Between 2 CNVs is < MERGEPARAM; Merge CNVs
            # Add to NetworkX Graph to Identify CNVs to Merge; Use Graph to find new MIN/MAX Coordinates -> MERGED INTERVAL
        # If Distance Between 2 CNVs is > MERGEPARAM; Don't Merge {Added to SINGLES2 List}
    # Get New List of CNVs
 def CONCATENATOR_PATIENT(l1):
    NEWREGION=[];MERGED_COORDINATES=[];ALLREGION=[];CHUNKS=[];DIFFERENCE=[];SINGLES1=[];SINGLES2=[];TMP=[];ALLCHUNKS=[]
    if (len(l1)>=2):
        ALLREGION=[i[0]+'_'+i[1] for i in l1]
        for y in range(0,len(l1)-1):
            if (abs(int(l1[y][1])-int(l1[y+1][0]))<=MERGEPARAM):
                NEWREGION.append([l1[y][0]+'_'+l1[y][1],l1[y+1][0]+'_'+l1[y+1][1]])
    else: SINGLES1.append(l1[0][0]+"_"+l1[0][1])

    g = networkx.Graph()
    for NR in NEWREGION:
        for edge in pairs(NR): g.add_edge(*edge)
    CHUNKS=networkx.connected_components(g)
    ALLCHUNKS=sum(CHUNKS,[])
    for j in CHUNKS:
            TMP=sum([[int(i.split('_')[0]),int(i.split('_')[1])] for i  in j],[])
            max_tmp=max(TMP)
            min_tmp=min(TMP)
            MERGED_COORDINATES.append([repr(min_tmp)+'_'+repr(max_tmp)])
    SINGLES2=list(set(ALLREGION).difference(set(ALLCHUNKS)))
    return [ i.split('_') for i in flatten(MERGED_COORDINATES+SINGLES2+SINGLES1) ]

 # Loop through patients' CNVs for specified CHROM+DIR
    # If 1 CNV: Add CNVs to SINGLES1 List
    # If 2+ CNVs: Add CNVs to ALLREGION List
        # If CNV DOES NOT Overlap Primary CNV Region: Add to SINGLES2
        # If CNV 100% Overlaps SegDup Cluster: Add to SINGLES2
        # If CNV Overlaps Primary, Not 100% Overlapped by SegDup Cluster, and <1 MB Between CNVs: Add to NEWREGION
            # If Region Betwen CNVs < 100kb: MERGE {Add to MERGE}
            # If Region Betwen CNVs Overlapped by 22q11.2 BP "B" Region: MERGE {Add to MERGE}
            # If Region Betwen CNVs >90% Overlapped by SegDup: MERGE { Add to MERGE}
            # Else add to SINGLES2
    # Add MERGE to NetworkX Graph to Identify CNVs to Merge; Use Graph to find new MIN/MAX Coordinates -> MERGED INTERVAL
    # Get New List of CNVs
 # Get Length for PROGRESS BAR
 CTR=[]
 for f in PATIENT_DATA.keys(): 
  for i in range(len(PATIENT_DATA[f.strip()])):
    CTR.append(f.strip()+'|'+PATIENT_DATA[f.strip()][i][0]+'|'+PATIENT_DATA[f.strip()][i][3])
 CTR = list(set(CTR))

 # For each PatientID in PATIENT_DATA Dictionary
    # Put CNVs into {Patient Specific} Dictionary with CHROM as Key; CNV as Value
    # For Each Patient Specific Chrom
	# Put CNVs into {Patient Specific} Dictionary with DIR as Key; CNV as Value 
        # For each DIR (Gain and/or Loss) *within* each CHROM
            # Merge CNVs if Distance < MERGEPARAM
        # If chr1, chr15, or chr22: Apply additional Merging Criteria
        # Write Merged CNVs to PATIENT_MERGED file
 PROGRESS = Bar('   Processing', max=len(CTR), suffix='%(percent)d%%   '+PFILE[0])
 for f in PATIENT_DATA.keys():
    TMP=make_chr(PATIENT_DATA[f])
    for h in TMP:
            GAIN_LOSS=gain_loss(TMP[h])
            for g in GAIN_LOSS:
                CONCAT_PATIENT=CONCATENATOR_PATIENT(GAIN_LOSS[g])
                for i in CONCAT_PATIENT: PATIENT_MERGED.write('\t'.join([ f.strip(), h.strip(), g.strip(), i[0], i[1] ]) + '\n')
                PROGRESS.next()
 PROGRESS.finish()
 PATIENT_MERGED.close()

except KeyboardInterrupt:
 print ''
 sys.exit(1)
