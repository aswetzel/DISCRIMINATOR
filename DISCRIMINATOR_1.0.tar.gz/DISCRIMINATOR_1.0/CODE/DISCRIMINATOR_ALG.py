#change the '/' operator to mean divide by
from __future__ import division 

# load required python modules
import os,sys,re,glob
from collections import defaultdict
from intervaltree import Interval, IntervalTree
from progress.bar import Bar

if len(sys.argv) != 6:
    print 'DISCRIMINATOR_ALG.py <MERGED COHORT FILE> <MERGED BENIGN FILE> <PRIMARY CNV FILE> <JACCARD INDEX> <HGXX>'
    sys.exit(2)

try:
 # Read Patient CNVs, Benign Intervals, Primary CNVs, and Gene/Exons from Specified Files
 PATH = os.path.dirname(os.path.realpath(__file__)).replace('/CODE','')
 PATIENT = open(sys.argv[1].strip(), 'r').readlines()
 BENIGN = open(sys.argv[2].strip(), 'r').readlines()
 PRIMARY = open(sys.argv[3].strip(), 'r').readlines()[1:]
 GENECOORD = PATH.strip() + '/CODE/DATA/GENE_BOUNDARIES_' + sys.argv[5] + '.bed'
 EXONCOORD = PATH.strip() + '/CODE/DATA/EXON_BOUNDARIES_' + sys.argv[5] + '.bed'

 # Add Patient Data to PATIENT_DATA Dictionary with PatientID as Key; CNV as Value
 PATIENT_DATA = defaultdict(list); ALLCNVS = defaultdict(list); PT_CHR = defaultdict(list)
 for k in PATIENT:
    tmp = k.strip().split('\t')
    DATA = [ tmp[1], tmp[3], tmp[4], tmp[2] ]
    PATIENT_DATA[tmp[0]].append(DATA)
    ALLCNVS[tmp[0]].append('_'.join(DATA))
    if tmp[0] not in PT_CHR[tmp[1]]: PT_CHR[tmp[1]].append(tmp[0]) 
 PTxCHR = sum([ len(PT_CHR[CHR]) for CHR in PT_CHR ]) # Total Number of PTxCHR Combinations

 # Add Benign Intervals to BENIGN_DATA Dictionary with Chrom as Key; Interval as Value
 BENIGN_DATA = defaultdict(list)
 for k in BENIGN:
    tmp = k.strip().split('\t')
    DATA = [ tmp[2], tmp[3], tmp[1] ]
    BENIGN_DATA[tmp[0]].append(DATA)
 B_CHR = BENIGN_DATA.keys()

 # Add Primary CNVs to PRIMARY_DATA Dictionary with Chrom as Key; Interval+ID as Value
 PRIMARY_DATA = defaultdict(list); ctr=1; FAIL=[]; DIR=[]
 for k in PRIMARY:
    ctr+=1
    if len(k.strip().split(',')) != 5: FAIL.append(ctr)
    else:
      try:
        tmp = k.strip().split(',')
        if 'GAIN' in tmp[4].strip().upper() and 'DUPLICATION' in tmp[3].strip().upper(): DATA = [tmp[1], tmp[2], tmp[3], 'GAIN']
        elif 'LOSS' in tmp[4].strip().upper() and 'DELETION' in tmp[3].strip().upper(): DATA = [tmp[1], tmp[2], tmp[3], 'LOSS']
        else: FAIL.append(ctr)        
        PRIMARY_DATA['chr'+tmp[0]].append(DATA)
      except IndexError:
        FAIL.append(ctr)
 P_CHR = PRIMARY_DATA.keys()
 if len(FAIL) > 0:
    print "\n"+"THE FOLLOWING LINES OF PRIMARY CNV FILE ['"+sys.argv[3].strip().split('/')[-1]+"'] HAVE INCORRECT FORMATTING: ",FAIL
    sys.exit()

 # If File Exists; Add to GENES/EXONS Dictionary with Gene/Exon ID as Key; Interval as Value
 GENE_BOUNDARIES=defaultdict(list); EXON_BOUNDARIES=defaultdict(list)
 if os.path.exists(GENECOORD) and os.path.exists(EXONCOORD):
    for gline in open(GENECOORD, 'r').readlines():
        DATA = gline.strip().split('\t')
        CHR_NO = DATA[1].strip()
        GENE_BOUNDARIES[CHR_NO].append([int(DATA[2]),int(DATA[3]),DATA[0]])
    for eline in open(EXONCOORD, 'r').readlines():
        DATA = eline.strip().split('\t')
        CHR_NO = DATA[1].strip()
        EXON_BOUNDARIES[CHR_NO].append([int(DATA[2]),int(DATA[3]),DATA[0]])
 elif os.path.exists(GENECOORD):
    print "EXON BOUNDARIES FILE DOES NOT EXIST FOR ['" +sys.argv[5]+"']"
    sys.exit()
 elif os.path.exists(EXONCOORD):
    print "GENE BOUNDARIES FILE DOES NOT EXIST FOR ['" +sys.argv[5]+"']"
    sys.exit()
 else:
    print "'\n' ERROR: BOTH GENE AND EXON BOUNDARIES FILES DO NOT EXIST FOR ['" +sys.argv[5]+"']"
    sys.exit()

 # Create PATIENT_CHR Dictionary
 # Loop through patient's CNVs and add each interval to PATIENT_CHR dictionary with CHROM as Key; [START, END, DIR] as Value
 def make_chr(l1):
    PATIENT_CHR=defaultdict(list)
    for i in l1: PATIENT_CHR[i[0].strip()].append(i[1:])
    return PATIENT_CHR

 # Create PATIENT_STATUS Dictionary
 # Loop through patient's CNVs for specified CHROM and add each interval to PATIENT_STATUS dictionary with DIR as Key; [START, END] as Value
 def gain_loss(l2):
    PATIENT_STATUS=defaultdict(list)
    for k1 in l2: PATIENT_STATUS[k1[-1]].append(k1[0:2])
    return PATIENT_STATUS

 # Create PRIMARY_CHR Dictionary
 # Loop through CNVs for specified CHROM and add each interval to PRIMARY_STATUS dictionary with DIR as Key; [START, END] as Value
 def gain_loss_primary(l2):
    PRIMARY_STATUS=defaultdict(list)
    for k1 in l2: PRIMARY_STATUS[k1[-1]].append(k1[0:3])
    return PRIMARY_STATUS

 # Calculate the overlap Betwen Patient CNV & Benign Interval(s)
 def overlap_benign(PATIENT, BENIGN):
    JI = []
    for a in PATIENT:
        HALF_CNV_LENGTH = int((abs(int(a[1]) - int(a[0])) + 1) * 0.5) # 1/2 Length of Patient CNV 
        INT = INT_BENIGN(a,BENIGN) # Get Intersection for Each Overlapping Benign Interval
        if len(INT) > 0: # If Overlapping Benign Region(s) Found
            SUM_INT = sum([ float(i) for i in INT ]) # Total Intersection of All Overlapping Benign Regions 
            if SUM_INT >= HALF_CNV_LENGTH: JI.append(a[0] + '_' + a[1] + '_' + 'BENIGN') # If >50% Overlapped by Benign Regions; CALL BENIGN
        elif len(INT) == 0: continue
    return JI

 # Calculate the Intersection, Union between Patient CNV & Benign/Primary Interval
 def INT_BENIGN(CNV, BENIGN):
    COLLECT=[]
    for a in BENIGN:
        I = min(int(CNV[1]), int(a[1])) + 1 - max(int(CNV[0]), int(a[0])) # Get Intersection of Benign + Patient CNV; No Intersection if Negative
        if I > 1: COLLECT.append(I) # If Patient CNV Intersects Benign Region; Add to COLLECT
    return COLLECT

 # Calculate the Jaccard Index Between Patient CNV & Primary CNV(s)
 def jaccard_index_primary(PATIENT, PRIMARY):
    JI = []
    for a in PATIENT:
        I_U = INT_PRIMARY(a, PRIMARY) # Get Intersection, Union Values for each Overlapping Primary CNV
        PASS = [ [i, float(i[0]/i[1])] for i in I_U if float(i[0]/i[1]) >= float(sys.argv[4].strip()) ] # List of Primary CNVs where JI > MIN
        if len(PASS) > 1:  # If Multiple Primary CNVs Exceed Minimum Threshold
            JACCARD = [ p[1] for p in PASS ]

            ANSWER = [[ a[0] +'_'+ a[1] + '_PRIMARY_' + p[0][2] ] for p in PASS if p[1] == max(JACCARD)][0]
        elif len(PASS) == 1: ANSWER = [ a[0] +'_'+ a[1] + '_PRIMARY_' + PASS[0][0][2] ] # Single Primary CNV Exceeds Minimum Threshold
        else: ANSWER = []  # No Primary CNV Exceeds Minimum Threshold
        JI.append(ANSWER)
    COLLECT = [ i for i in JI if len(i) > 0 ]
    return COLLECT

 def INT_PRIMARY(CNV, PRIMARY):
    COLLECT=[]
    for a in PRIMARY:
        I = min(int(CNV[1]), int(a[1])) + 1 - max(int(CNV[0]), int(a[0])) # Get Intersection of Benign + Patient CNV; No Intersection if Negative
        U = max(int(CNV[1]), int(a[1])) + 1 - min(int(CNV[0]), int(a[0])) # Get Union of Benign + Patient CNV
        if I > 1: COLLECT.append([I, U, a[-1]]) # If Patient CNV Intersects Benign Region; Add to COLLECT
    return COLLECT

 # Function to Flatten Lists
 def flatten(ALL):
    FLAT=[]
    for sublist in ALL:
        if type(sublist) == str: FLAT.append(sublist)
        if type(sublist) == list: 
            if len(sublist) >1: 
                for item in sublist: FLAT.append(item)
            else: FLAT.append(sublist)
    return FLAT


 # ASSIGNING PROVISIONAL CLASSIFICATIONS #
 PTFILE = sys.argv[1].strip().replace('.txt','')
 BFILE = sys.argv[2].strip().split('/')[-1].replace('_MERGED','').replace('.txt','')
 PFILE = sys.argv[3].strip().split('/')[-1].replace('.csv','')
 THRSH = sys.argv[4].strip()

 # For each PatientID in PATIENT_DATA Dictionary
    # Put CNVs into {Patient Specific} Dictionary with CHROM as Key; CNV as Value
    # Determine which CHR(s) have both PRIMARY CNV and PATIENT CNVS
    # Determine which CHR(s) have both BENIGN INTERVALS and PATIENT CNVS

    # For Each Patient Specific Chrom
	# Put Patient CNVs into Dictionary with DIR as Key; CNV as Value 
        # Put Benign Intervals into Dictionary with DIR as Key; Interval as Value
        # For each DIR (Gain and/or Loss) *within* each CHROM
        # If Chrom Has Patient & Primary CNV(s):
            # Loop Through Patient CNVs
        # Else:
 TOPROCESS = '_'.join([ PTFILE, BFILE, PFILE, THRSH, 'COLLAPSEDANNOTATIONS.txt' ]).split('/')[-1]
 PROGRESS = Bar('   Processing', max=PTxCHR+3+len(ALLCNVS.keys()), suffix='%(percent)d%%   '+ TOPROCESS)
 BENIGN_FINAL = []; PRIMARY_FINAL = []; MISSING = []
 for f in PATIENT_DATA.keys():
    BENIGNvsPATIENT = []; PRIMARYvsPATIENT = []
    TMP = make_chr(PATIENT_DATA[f.strip()]) # Patient+Chrom CNVs Dictionary
    PRIMARYvsPATIENT = list(set(P_CHR).intersection(set(TMP.keys()))) # List of Chroms with Patient CNV(s) and Primary CNV(s)
    BENIGNvsPATIENT = list(set(B_CHR).intersection(set(TMP.keys()))) # List of Chroms with Patient CNV(s) and Benign Region(s)

    for h in TMP:
        PATIENT_GAIN_LOSS = gain_loss(TMP[h]) # Patient Specific Dictionary
        BENIGN_GAIN_LOSS = gain_loss(BENIGN_DATA[h]) # Benign Specific Dictiorary
        PRIMARY_GAIN_LOSS = gain_loss_primary(PRIMARY_DATA[h]) # Primary Specific Dictiorary

        # If Chrom Has CNV and Benign Intervals:
            # Loop Through Patient CNVs
            # If Patient CNV >50% Overlapped by 1+ Benign Regions --> BENIGN; Else --> NOT
            # If Patient CNV >40% Jaccard Index --> Primary; Else --> NOT
        if h in PRIMARYvsPATIENT and h in BENIGNvsPATIENT:
            for g in PATIENT_GAIN_LOSS:  

               # Benign Overlap Calculation
               CNVS = [ x[0] + '_' + x[1] for x in PATIENT_GAIN_LOSS[g] ]
               btmp = overlap_benign(PATIENT_GAIN_LOSS[g], BENIGN_GAIN_LOSS[g]) 
               BENIGN = [ '_'.join(u.split('_')[0:2]) for u in btmp ]
               bNOT = [ i + "_NOT" for i in list(set(CNVS).difference(set(BENIGN))) ] 
               BENIGN_FINAL.append([ f +'|'+ h +'_'+ g +'_'+ i for i in btmp + bNOT ])

               # Primary Jaccard Calculation
               ptmp =  sum(jaccard_index_primary(PATIENT_GAIN_LOSS[g], PRIMARY_GAIN_LOSS[g]),[])
               PRIMARY = [ '_'.join(u[0].split('_')[0:2]) for u in ptmp ]
               pNOT = [ i + "_NOT" for i in list(set(CNVS).difference(set(PRIMARY))) ] 
               PRIMARY_FINAL.append([ f +'|'+ h +'_'+ g +'_'+ i for i in ptmp + pNOT ])

        # If Chrom Has CNV and Benign Intervals:
            # Loop Through Patient CNVs
            # If Patient CNV >50% Overlapped by 1+ Benign Regions --> BENIGN; Else --> NOT
        elif h in BENIGNvsPATIENT:
            for g in PATIENT_GAIN_LOSS: 
               CNVS = [ x[0] + '_' + x[1] for x in PATIENT_GAIN_LOSS[g] ]
               btmp = overlap_benign(PATIENT_GAIN_LOSS[g], BENIGN_GAIN_LOSS[g]) 
               BENIGN = [ '_'.join(u.split('_')[0:2]) for u in btmp ]
               bNOT = [ i + "_NOT" for i in list(set(CNVS).difference(set(BENIGN))) ] 
               BENIGN_FINAL.append([ f +'|'+ h +'_'+ g +'_'+ i for i in btmp + bNOT ])

        # If Chrom Has CNV and Pathogenic Intervals:
            # Loop Through Patient CNVs
            # If Patient CNV >40% Jaccard Index --> Primary; Else --> NOT
        elif h in PRIMARYvsPATIENT:
            for g in PATIENT_GAIN_LOSS: 
               CNVS = [ x[0] + '_' + x[1] for x in PATIENT_GAIN_LOSS[g] ]
               ptmp =  jaccard_index_primary(PATIENT_GAIN_LOSS[g], PRIMARY_GAIN_LOSS[g]) 
               PRIMARY = [ '_'.join(u[0].split('_')[0:2]) for u in ptmp ]
               pNOT = [ i + "_NOT" for i in list(set(CNVS).difference(set(PRIMARY))) ] 
               PRIMARY_FINAL.append([ f +'|'+ h +'_'+ g +'_'+ i for i in ptmp + pNOT ])

        # If Chrom Has CNV But Not Benign or Pathogenic Intervals
        elif not h in PRIMARYvsPATIENT and not h in BENIGNvsPATIENT:
            for g in PATIENT_GAIN_LOSS: 
               MISSING.append([ f +'|'+ h +'_'+ g +'_'+ i[0] +'_'+ i[1] +'_'+ 'NOT' for i in PATIENT_GAIN_LOSS[g] ])

        # Process Next PTxCHR Combination
        PROGRESS.next()


 BENIGN_FINAL = sum(BENIGN_FINAL, [])
 PRIMARY_FINAL = sum(PRIMARY_FINAL, [])
 MISSING = sum(MISSING, [])
 B_DICT = {}; P_DICT = {}; M_DICT = {}


 # Loop Over Benign Calls
    # Add to Benign Dictionary with PatientID as Key; CNV+Call as Value
 for b in BENIGN_FINAL:
    PT_KEY = b.split('|')[0]
    if PT_KEY in B_DICT.keys(): B_DICT[PT_KEY].append(b.split('|')[1]) # IF PatientID Found; Add to Dictionary
    else: B_DICT[PT_KEY] = [b.split('|')[1]] # If Patient ID NOT FOUND; Add Key to Dictionary
 PROGRESS.next()

 # Loop Over Primary Calls
    # Add to Primary Dictionary with PatientID as Key; CNV+Call as Value
 for p in PRIMARY_FINAL:
    PT_KEY = p.split('|')[0]
    if PT_KEY in P_DICT.keys(): P_DICT[PT_KEY].append(p.split('|')[1]) # IF PatientID Found; Add to Dictionary
    else: P_DICT[PT_KEY] = [p.split('|')[1]] # If Patient ID NOT FOUND; Add Key to Dictionary
 PROGRESS.next()
 
 # Loop Over Missing Calls
    # Add to Primary Dictionary with PatientID as Key; CNV+Call as Value
 if len(MISSING) > 0:
  for m in MISSING:
    PT_KEY = m.split('|')[0]
    if PT_KEY in M_DICT.keys(): M_DICT[PT_KEY].append(m.split('|')[1]) # IF PatientID Found; Add to Dictionary
    else: M_DICT[PT_KEY] = [m.split('|')[1]] # If Patient ID NOT FOUND; Add Key to Dictionary
 PROGRESS.next()

 # Loop Through All Patient CNVs and Write CALLS to File
 OFILE = []
 for PT in ALLCNVS.keys():
    BCNVS = []; PCNVS = []

    # Get List of CNVs in B_DICT
    if PT in B_DICT.keys(): BCNVS = [ '_'.join([ b.split('_')[0], b.split('_')[2], b.split('_')[3], b.split('_')[1] ]) for b in B_DICT[PT] ]

    # Get List of CNVs in P_DICT
    if PT in P_DICT.keys(): PCNVS = [ '_'.join([ p.split('_')[0], p.split('_')[2], p.split('_')[3], p.split('_')[1] ]) for p in P_DICT[PT] ]

    for CNV in ALLCNVS[PT]:

        # Get Gene/Exon Overlaps
        GB_CHR = GENE_BOUNDARIES[CNV.split('_')[0]]
        EB_CHR = EXON_BOUNDARIES[CNV.split('_')[0]]
        CNV_COORD = [ int(CNV.split('_')[1]), int(CNV.split('_')[2]) ]
        GENELIST = set([ GENE[-1].strip() for GENE in GB_CHR if max(CNV_COORD[0],GENE[0])-min(CNV_COORD[1],GENE[1]) < 0 ])
        EXONLIST = set([ EXON[-1].strip() for EXON in EB_CHR if max(CNV_COORD[0],EXON[0])-min(CNV_COORD[1],EXON[1]) < 0 ])
        if len(EXONLIST) == 0: EXONLIST = '.'

        # If Non-Coding CNV
        if len(GENELIST) == 0:
            if CNV in PCNVS:
                CNV2 = '_'.join([ CNV.split('_')[0], CNV.split('_')[3], CNV.split('_')[1], CNV.split('_')[2] ])
                PCALL = [ each.split('_')[-1] for each in P_DICT[PT] if CNV2 in each ][0]
                if PCALL != 'NOT': OFILE.append( flatten([ PT, CNV.split('_'), ".", ".", "PRIMARY", PCALL ]) )
                else: OFILE.append( flatten([ PT, CNV.split('_'), ".", ".", "NON-CODING", "."]))
            else: OFILE.append( flatten([ PT, CNV.split('_'), ".", ".", "NON-CODING", "."]))

        # If CNV was Evaluated for both BENIGN & PRIMARY 
        elif CNV in BCNVS and CNV in PCNVS:
            CNV2 = '_'.join([ CNV.split('_')[0], CNV.split('_')[3], CNV.split('_')[1], CNV.split('_')[2] ])
            BCALL = [ each.split('_')[-1] for each in B_DICT[PT] if CNV2 in each ][0]
            PCALL = [ each.split('_')[-1] for each in P_DICT[PT] if CNV2 in each ][0]

            if PCALL != 'NOT': OFILE.append( flatten([ PT, CNV.split('_'), ';'.join(sorted(GENELIST)), ';'.join(sorted(EXONLIST)), "PRIMARY", PCALL ]))
            elif BCALL != 'NOT': OFILE.append( flatten([ PT, CNV.split('_'), ';'.join(sorted(GENELIST)), ';'.join(sorted(EXONLIST)), "BENIGN", "." ]))
            elif PCALL == 'NOT' and BCALL == 'NOT': OFILE.append( flatten([ PT, CNV.split('_'), ';'.join(sorted(GENELIST)), ';'.join(sorted(EXONLIST)), "SECONDARY", "." ]))

        # If CNV was Evaluated for BENIGN
        elif CNV in BCNVS and not CNV in PCNVS: 
            CNV2 = '_'.join([ CNV.split('_')[0], CNV.split('_')[3], CNV.split('_')[1], CNV.split('_')[2] ])
            CALL = [ each.split('_')[-1] for each in B_DICT[PT] if CNV2 in each ][0]
            if CALL == "NOT": OFILE.append( flatten([ PT, CNV.split('_'), ';'.join(sorted(GENELIST)), ';'.join(sorted(EXONLIST)), "SECONDARY", "." ]))
            else: OFILE.append( flatten([ PT, CNV.split('_'), ';'.join(sorted(GENELIST)), ';'.join(sorted(EXONLIST)), "BENIGN", "." ]))

        # If CNV was Evaluated for PRIMARY
        elif CNV in PCNVS and not CNV in BCNVS:
            CNV2 = '_'.join([ CNV.split('_')[0], CNV.split('_')[3], CNV.split('_')[1], CNV.split('_')[2] ])
            CALL = [ each.split('_')[-1] for each in P_DICT[PT] if CNV2 in each ][0]
            if CALL == "NOT": OFILE.append( flatten([ PT, CNV.split('_'), ';'.join(sorted(GENELIST)), ';'.join(sorted(EXONLIST)), "SECONDARY", "." ]))
            else: OFILE.append( flatten([ PT, CNV.split('_'), ';'.join(sorted(GENELIST)), ';'.join(sorted(EXONLIST)), "PRIMARY", CALL ]))

        # If CNV was NOT Evaluated for both BENIGN and PRIMARY
        else:
            OFILE.append( flatten([ PT, CNV.split('_'), ';'.join(sorted(GENELIST)), ';'.join(sorted(EXONLIST)), "ERROR", "." ]))

    PROGRESS.next()
 PROGRESS.finish()


 # Loop Through All Patient CNVs and Write CALLS to File
 OFINAL = open( '_'.join([ PTFILE, BFILE, PFILE, THRSH, 'COLLAPSEDANNOTATIONS.txt' ]), 'w')
 OFINAL.write('\t'.join([ "PATIENTID", "CHROM", "START", "END" , "DIR", "GENELIST", "EXONLIST", "CALL", "PRIMARY_CNV" ])+'\n')
 for OF in sorted(OFILE, key=lambda x: (x[0], int(x[1].replace('chr','').replace('X','24').replace('Y','25')), int(x[2]))):
    OFINAL.write('\t'.join(OF) + '\n')
 OFINAL.close()

except KeyboardInterrupt:
 print ''
 sys.exit(1)
