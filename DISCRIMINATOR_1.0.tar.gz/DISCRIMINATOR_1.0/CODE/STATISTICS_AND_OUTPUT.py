#change the '/' operator to mean divide by
from __future__ import division 

# load required python modules
import sys, os
from collections import defaultdict
from collections import Counter

if len(sys.argv) != 5:
    print 'STATISTICS_AND_OUTPUT.py <MERGED COHORT FILE> <MERGED BENIGN FILE> <PRIMARY CNV FILE> <JACCARD INDEX>'
    sys.exit(2)

try:
 # Read Patient CNVs, Benign Intervals, and Primary CNVs from Specified Files
 PATH = os.path.dirname(os.path.realpath(__file__)).replace('/CODE','')
 PRIMARYFILE = open(sys.argv[3].strip(), 'r').readlines()[1:]
 PTFILE = sys.argv[1].strip().replace('.txt','')
 BFILE = sys.argv[2].strip().split('/')[-1].replace('_MERGED','').replace('.txt','')
 PFILE = sys.argv[3].strip().split('/')[-1].replace('.csv','')
 THRSH = sys.argv[4].strip()
 COLLAPSED = open(PTFILE +'_'+ BFILE +'_'+ PFILE +'_'+ THRSH + '_COLLAPSEDANNOTATIONS.txt', 'r').readlines()[1:]

 # Write Basic Info to 'COMPLETE OUTPUT' File
 COMPLETE_OUTPUT = open(PTFILE +'_'+ BFILE +'_'+ PFILE +'_'+ THRSH + '_COMPLETE_OUTPUT.txt', "w")
 COMPLETE_OUTPUT.write("Primary CNV File Used:"+'\t'+sys.argv[3].strip().split('/')[-1] + '\n')
 COMPLETE_OUTPUT.write("Benign CNV File Used:"+'\t'+sys.argv[2].strip().split('/')[-1] + '\n')
 COMPLETE_OUTPUT.write("Patient CNV File Used:"+'\t'+sys.argv[1].strip().split('/')[-1] + '\n')
 COMPLETE_OUTPUT.write('\n')

 # Process COLLAPSED ANNOTATION FILE
 PATIENT_DATA = defaultdict(list)
 GENES_DICT=defaultdict(list); EXONS_DICT=defaultdict(list)
 GAIN_PRIMARY=defaultdict(list); LOSS_PRIMARY=defaultdict(list)
 GAIN_SECONDARY=defaultdict(list); LOSS_SECONDARY=defaultdict(list)
 for k in COLLAPSED:
    tmp = k.strip().split('\t')

    # Add Patient Data to PATIENT_DATA Dictionary with PatientID as Key; CNV as Value
    PATIENT_DATA[tmp[0]].append([ tmp[1], tmp[2], tmp[3], tmp[4], tmp[7], tmp[8], tmp[5], tmp[6] ])

    # Add Genes to DirectionxClassification Dictionary with PatientID+Chrom as Key; GeneList as Value
    if tmp[-2] == 'PRIMARY' and tmp[4] == 'GAIN': GAIN_PRIMARY[tmp[0]].append(tmp[5])
    elif tmp[-2] == 'PRIMARY' and tmp[4] == 'LOSS': LOSS_PRIMARY[tmp[0]].append(tmp[5])
    elif tmp[-2] == 'SECONDARY' and tmp[4] == 'GAIN': GAIN_SECONDARY[tmp[0]].append(tmp[5])
    elif tmp[-2] == 'SECONDARY' and tmp[4] == 'LOSS': LOSS_SECONDARY[tmp[0]].append(tmp[5])
    for GENE in tmp[5].split(';'): GENES_DICT[GENE.strip()].append(tmp[4].strip()) # Create List of Genes Deleted/Duplicated
    for EXON in tmp[6].split(';'): EXONS_DICT[EXON.strip()].append(tmp[4].strip()) # Create List of Exons Deleted/Duplicated

 # Write Total Number of Patient to File
 COMPLETE_OUTPUT.write("Number of Patients in Cohort"+'\t'+repr(len(PATIENT_DATA.keys()))+'\n')
 COMPLETE_OUTPUT.write('\n')

 # Add Primary CNVs to PRIMARY_DATA Dictionary with Chrom as Key; Interval+ID as Value
 PRIMARY_DATA = defaultdict(list); PRIMARY_LIST=[]
 FIFTYKB=defaultdict(int); HUNDKB=defaultdict(int);FIVEHUNDKB=defaultdict(int); ONEMB=defaultdict(int) # Create Dictionaries for Size Thresholds
 CTR=1
 for k in PRIMARYFILE:
    tmp = k.strip().split(',') 
    DATA = [tmp[1], tmp[2], tmp[3]]
    PCNVL = int(DATA[1])-int(DATA[0])+1 # Length of Primary CNV

    # Add Primary CNVs to Dictionary Based on Length
    if PCNVL >= 1000000: ONEMB[DATA[2]]+=1; FIVEHUNDKB[DATA[2]]+=1; HUNDKB[DATA[2]]+=1; FIFTYKB[DATA[2]]+=1
    elif PCNVL >= 500000: FIVEHUNDKB[DATA[2]]+=1; HUNDKB[DATA[2]]+=1; FIFTYKB[DATA[2]]+=1
    elif PCNVL >= 100000: HUNDKB[DATA[2]]+=1; FIFTYKB[DATA[2]]+=1
    elif PCNVL >= 50000: FIFTYKB[DATA[2]]+=1

 # Define Function to Determine Sample CNV Length
 def DATA_KB(COORD,L50,L100,L500,L1000):
    L50+=len([i for i in COORD if (int(i[1])-int(i[0]))>=50000])
    L100+=len([i for i in COORD if (int(i[1])-int(i[0]))>=100000])
    L500+=len([i for i in COORD if (int(i[1])-int(i[0]))>=500000])
    L1000+=len([i for i in COORD if (int(i[1])-int(i[0]))>=1000000])
    return [L50,L100,L500,L1000]
    
 # Initalize Values as '0'
 PRI_FIFTYKB, PRI_HUNDKB, PRI_FIVEHUNDKB, PRI_ONEMB, PRI_FIFTYKB_G, PRI_HUNDKB_G, PRI_FIVEHUNDKB_G, PRI_ONEMB_G, PRI_FIFTYKB_L, PRI_HUNDKB_L, PRI_FIVEHUNDKB_L, PRI_ONEMB_L=(0,)*12
 SEC_FIFTYKB, SEC_HUNDKB, SEC_FIVEHUNDKB, SEC_ONEMB, SEC_FIFTYKB_G, SEC_HUNDKB_G, SEC_FIVEHUNDKB_G, SEC_ONEMB_G, SEC_FIFTYKB_L, SEC_HUNDKB_L, SEC_FIVEHUNDKB_L, SEC_ONEMB_L=(0,)*12
 BEN_FIFTYKB, BEN_HUNDKB, BEN_FIVEHUNDKB, BEN_ONEMB, BEN_FIFTYKB_G, BEN_HUNDKB_G, BEN_FIVEHUNDKB_G, BEN_ONEMB_G, BEN_FIFTYKB_L, BEN_HUNDKB_L, BEN_FIVEHUNDKB_L, BEN_ONEMB_L=(0,)*12
 NC_FIFTYKB, NC_HUNDKB, NC_FIVEHUNDKB, NC_ONEMB, NC_FIFTYKB_G, NC_HUNDKB_G, NC_FIVEHUNDKB_G, NC_ONEMB_G, NC_FIFTYKB_L, NC_HUNDKB_L, NC_FIVEHUNDKB_L, NC_ONEMB_L=(0,)*12

 # Create Variables for Counting CNVs & Co-Occuring Secondary CNVs
 PRIMARYO=[]; PRIMARYO_GAIN=[]; PRIMARYO_LOSS=[]
 SECONDARYO=[]; SECONDARYO_GAIN=[]; SECONDARYO_LOSS=[]
 BENIGNO=[]; BENIGNO_GAIN=[]; BENIGNO_LOSS=[]
 NONCODINGO=[]; NONCODINGO_GAIN=[]; NONCODINGO_LOSS=[]
 COSECONDARY=defaultdict(int); COSECONDARY_GAIN=defaultdict(int); COSECONDARY_LOSS=defaultdict(int)

 # For each PatientID in PATIENT_DATA Dictionary
 PT_CTR = defaultdict(list); PRIMARY_GL_DICT=defaultdict(list)
 for PT in sorted(PATIENT_DATA.keys()):
    COUNTER_P=0; COUNTER_S=0; COUNTER_B=0; COUNTER_NC=0 # Counters for Provisional Pathogenicity
    P_G=0; S_G=0; B_G=0; NC_G=0 # Counters for GAIN events
    P_L=0; S_L=0; B_L=0; NC_L=0 # Counters for LOSS events
    
    # For each CNV; Add to Appropriate Counter
    for CNV in PATIENT_DATA[PT]: 

      if 'GAIN' in CNV and 'PRIMARY' in CNV: COUNTER_P+=1; P_G+=1
      elif 'GAIN' in CNV and 'SECONDARY' in CNV: COUNTER_S+=1; S_G+=1
      elif 'GAIN' in CNV and 'BENIGN' in CNV: COUNTER_B+=1; B_G+=1
      elif 'GAIN' in CNV and 'NON-CODING' in CNV: COUNTER_NC+=1; NC_G+=1

      elif 'LOSS' in CNV and 'PRIMARY' in CNV: COUNTER_P+=1; P_L+=1
      elif 'LOSS' in CNV and 'SECONDARY' in CNV: COUNTER_S+=1; S_L+=1
      elif 'LOSS' in CNV and 'BENIGN' in CNV: COUNTER_B+=1; B_L+=1
      elif 'LOSS' in CNV and 'NON-CODING' in CNV: COUNTER_NC+=1; NC_L+=1

    # Send Counter Values to PT_CTR Dictionary
    PT_CTR[PT].append([ COUNTER_P, COUNTER_S, COUNTER_B, COUNTER_NC, P_G,P_L, S_G,S_L, B_G,B_L, NC_G,NC_L ])

    # Count the Number of Primary CNVs
    P = [ i[1:3] for i in PATIENT_DATA[PT] if 'PRIMARY' in i ]
    PG = [ i[1:3] for i in PATIENT_DATA[PT] if 'PRIMARY' in i and 'GAIN' in i ]
    PL = [ i[1:3] for i in PATIENT_DATA[PT] if 'PRIMARY' in i and 'LOSS' in i ]

    # Count the Number of Secondary CNVs
    S = [ i[1:3] for i in PATIENT_DATA[PT] if 'SECONDARY' in i ]
    SG = [ i[1:3] for i in PATIENT_DATA[PT] if 'SECONDARY' in i and 'GAIN' in i ]
    SL = [ i[1:3] for i in PATIENT_DATA[PT] if 'SECONDARY' in i and 'LOSS' in i ]

    # Count the Number of Benign CNVs
    B = [ i[1:3] for i in PATIENT_DATA[PT] if 'BENIGN' in i ]
    BG = [ i[1:3] for i in PATIENT_DATA[PT] if 'BENIGN' in i and 'GAIN' in i ]
    BL = [ i[1:3] for i in PATIENT_DATA[PT] if 'BENIGN' in i and 'LOSS' in i ]

    # Count the Number of Non-Coding CNVs
    NC = [ i[1:3] for i in PATIENT_DATA[PT] if 'NON-CODING' in i ]
    NCG = [ i[1:3] for i in PATIENT_DATA[PT] if 'NON-CODING' in i and 'GAIN' in i ]
    NCL = [ i[1:3] for i in PATIENT_DATA[PT] if 'NON-CODING' in i and 'LOSS' in i ]

    # Count the Number of Primary CNVs in each Length Group
    if len(P) > 0: 
        PRIMARYO.append(DATA_KB( P, PRI_FIFTYKB, PRI_HUNDKB, PRI_FIVEHUNDKB, PRI_ONEMB ))
        PRIMARYO_GAIN.append(DATA_KB( PG, PRI_FIFTYKB_G,PRI_HUNDKB_G,PRI_FIVEHUNDKB_G,PRI_ONEMB_G ))
        PRIMARYO_LOSS.append(DATA_KB( PL, PRI_FIFTYKB_L,PRI_HUNDKB_L,PRI_FIVEHUNDKB_L,PRI_ONEMB_L ))

    # Count the Number of Secondary CNVs in each Length Group
    if len(S) > 0: 
        SECONDARYO.append(DATA_KB( S, SEC_FIFTYKB, SEC_HUNDKB, SEC_FIVEHUNDKB, SEC_ONEMB ))
        SECONDARYO_GAIN.append(DATA_KB( SG, SEC_FIFTYKB_G,SEC_HUNDKB_G,SEC_FIVEHUNDKB_G,SEC_ONEMB_G ))
        SECONDARYO_LOSS.append(DATA_KB( SL, SEC_FIFTYKB_L,SEC_HUNDKB_L,SEC_FIVEHUNDKB_L,SEC_ONEMB_L ))

    # Count the Number of Benign CNVs in each Length Group
    if len(B) > 0: 
        BENIGNO.append(DATA_KB( B, BEN_FIFTYKB, BEN_HUNDKB, BEN_FIVEHUNDKB, BEN_ONEMB ))
        BENIGNO_GAIN.append(DATA_KB( BG, BEN_FIFTYKB_G,BEN_HUNDKB_G,BEN_FIVEHUNDKB_G,BEN_ONEMB_G ))
        BENIGNO_LOSS.append(DATA_KB( BL, BEN_FIFTYKB_L,BEN_HUNDKB_L,BEN_FIVEHUNDKB_L,BEN_ONEMB_L ))

    # Count the Number of Non-Coding CNVs in each Length Group
    if len(NC) > 0: 
        NONCODINGO.append(DATA_KB( NC, NC_FIFTYKB, NC_HUNDKB, NC_FIVEHUNDKB, NC_ONEMB ))
        NONCODINGO_GAIN.append(DATA_KB( NCG, NC_FIFTYKB_G,NC_HUNDKB_G,NC_FIVEHUNDKB_G,NC_ONEMB_G ))
        NONCODINGO_LOSS.append(DATA_KB( NCL, NC_FIFTYKB_L,NC_HUNDKB_L,NC_FIVEHUNDKB_L,NC_ONEMB_L ))

    # Loop over Patient Data and Add Primary CNV + Direction to Dictionary with PCNV as Key; PatientID as Value
    PRIMARY_GL = sum([ [CNV[5]] for CNV in PATIENT_DATA[PT] if 'PRIMARY' in CNV], [])
    for pgl in PRIMARY_GL: PRIMARY_GL_DICT[pgl].append(PT)

    # If Primary CNV Found; Get List of Co-Occuring Secondary CNVs
    PCNV = [ i[5] for i in PATIENT_DATA[PT] if 'PRIMARY' in i ]
    if len(PCNV) > 0:
      for pcnv in PCNV:
          COSECONDARY[pcnv]+=COUNTER_S
          COSECONDARY_GAIN[pcnv]+=S_G
          COSECONDARY_LOSS[pcnv]+=S_L

 # Get Counts of Pathogenicity Classifications [WITH/WITHOUT] Direction
 PRIMARY=0; SECONDARY=0; BENIGN=0; NONCODING=0
 PRIMARY_G=0; PRIMARY_L=0; SECONDARY_G=0; SECONDARY_L=0; BENIGN_G=0; BENIGN_L=0; NONCODING_G=0; NONCODING_L=0
 for PT in PT_CTR.keys():

    # Total Cohort Counts for Each Pathogenicity Classification
    PRIMARY+=int(PT_CTR[PT.strip()][-1][0])
    SECONDARY+=int(PT_CTR[PT.strip()][-1][1])
    BENIGN+=int(PT_CTR[PT.strip()][-1][2])
    NONCODING+=int(PT_CTR[PT.strip()][-1][3])

    # Total Cohort Counts for Each DirectionxPathogenicity Classification
    PRIMARY_G+=int(PT_CTR[PT.strip()][-1][4])
    PRIMARY_L+=int(PT_CTR[PT.strip()][-1][5])
    SECONDARY_G+=int(PT_CTR[PT.strip()][-1][6])
    SECONDARY_L+=int(PT_CTR[PT.strip()][-1][7])
    BENIGN_G+=int(PT_CTR[PT.strip()][-1][8])
    BENIGN_L+=int(PT_CTR[PT.strip()][-1][9])
    NONCODING_G+=int(PT_CTR[PT.strip()][-1][10])
    NONCODING_L+=int(PT_CTR[PT.strip()][-1][11])

 # Write Total Number of CNVs to File
 COMPLETE_OUTPUT.write("Total Number of Primary CNVs in Cohort"+'\t'+repr(PRIMARY)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Secondary CNVs in Cohort"+'\t'+repr(SECONDARY)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Benign CNVs in Cohort"+'\t'+repr(BENIGN)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Coding CNVs in Cohort"+'\t'+repr(NONCODING)+'\n')

 # Write Total Number of [GAIN/LOSS] CNVs Per Patient to File
 COMPLETE_OUTPUT.write("Total Number of Primary CNVs GAINS in Cohort"+'\t'+repr(PRIMARY_G)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Secondary CNVs GAINS in Cohort"+'\t'+repr(SECONDARY_G)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Benign CNVs GAINS in Cohort"+'\t'+repr(BENIGN_G)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Coding CNVs GAINS in Cohort"+'\t'+repr(NONCODING_G)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Primary CNVs LOSS in Cohort"+'\t'+repr(PRIMARY_L)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Secondary CNVs LOSS in Cohort"+'\t'+repr(SECONDARY_L)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Benign CNVs LOSS in Cohort"+'\t'+repr(BENIGN_L)+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Coding CNVs LOSS in Cohort"+'\t'+repr(NONCODING_L)+'\n')
 COMPLETE_OUTPUT.write('\n')

 # Write Average Number of CNVs Per Patient to File
 COMPLETE_OUTPUT.write("Average Number of Primary CNVs per Patient"+'\t'+repr(PRIMARY/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Secondary CNVs per Patient"+'\t'+repr(SECONDARY/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Benign CNVs per Patient"+'\t'+repr(BENIGN/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Coding CNVs per Patient"+'\t'+repr(NONCODING/len(PT_CTR.keys()))+'\n')

 # Write Average Number of [GAIN/LOSS] CNVs Per Patient to File
 COMPLETE_OUTPUT.write("Average Number of Primary CNVs GAINS per Patient"+'\t'+repr(PRIMARY_G/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Secondary CNVs GAINS per Patient"+'\t'+repr(SECONDARY_G/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Benign CNVs GAINS per Patient"+'\t'+repr(BENIGN_G/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Coding CNVs GAINS per Patient"+'\t'+repr(NONCODING_G/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Primary CNVs LOSS per Patient"+'\t'+repr(PRIMARY_L/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Secondary CNVs LOSS per Patient"+'\t'+repr(SECONDARY_L/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Benign CNVs LOSS per Patient"+'\t'+repr(BENIGN_L/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Coding CNVs LOSS per Patient"+'\t'+repr(NONCODING_L/len(PT_CTR.keys()))+'\n')
 COMPLETE_OUTPUT.write('\n')

 # Write Total Number of CNVs by Length Group to File
 COMPLETE_OUTPUT.write("Total Number of CNVs > 50kb in Cohort"+'\t'+repr(sum([ po[0] for po in PRIMARYO ]) + sum([ so[0] for so in SECONDARYO ]) + sum([ bo[0] for bo in BENIGNO ]) + sum([ nco[0] for nco in NONCODINGO ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs > 100kb in Cohort"+'\t'+repr(sum([ po[1] for po in PRIMARYO ]) + sum([ so[1] for so in SECONDARYO ]) + sum([ bo[1] for bo in BENIGNO ]) + sum([ nco[1] for nco in NONCODINGO ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs > 500kb in Cohort"+'\t'+repr(sum([ po[2] for po in PRIMARYO ]) + sum([ so[2] for so in SECONDARYO ]) + sum([ bo[2] for bo in BENIGNO ]) + sum([ nco[2] for nco in NONCODINGO ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs > 1Mb in Cohort"+'\t'+repr(sum([ po[3] for po in PRIMARYO ]) + sum([ so[3] for so in SECONDARYO ]) + sum([ bo[3] for bo in BENIGNO ]) + sum([ nco[3] for nco in NONCODINGO ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs GAINS > 50kb in Cohort"+'\t'+repr(sum([ po[0] for po in PRIMARYO_GAIN ]) + sum([ so[0] for so in SECONDARYO_GAIN ]) + sum([ bo[0] for bo in BENIGNO_GAIN ]) + sum([ nco[0] for nco in NONCODINGO_GAIN ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs GAINS > 100kb in Cohort"+'\t'+repr(sum([ po[1] for po in PRIMARYO_GAIN ]) + sum([ so[1] for so in SECONDARYO_GAIN ]) + sum([ bo[1] for bo in BENIGNO_GAIN ]) + sum([ nco[1] for nco in NONCODINGO_GAIN ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs GAINS > 500kb in Cohort"+'\t'+repr(sum([ po[2] for po in PRIMARYO_GAIN ]) + sum([ so[2] for so in SECONDARYO_GAIN ]) + sum([ bo[2] for bo in BENIGNO_GAIN ]) + sum([ nco[2] for nco in NONCODINGO_GAIN ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs GAINS > 1Mb in Cohort"+'\t'+repr(sum([ po[3] for po in PRIMARYO_GAIN ]) + sum([ so[3] for so in SECONDARYO_GAIN ]) + sum([ bo[3] for bo in BENIGNO_GAIN ]) + sum([ nco[3] for nco in NONCODINGO_GAIN ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs LOSSES > 50kb in Cohort"+'\t'+repr(sum([ po[0] for po in PRIMARYO_LOSS ]) + sum([ so[0] for so in SECONDARYO_LOSS ]) + sum([ bo[0] for bo in BENIGNO_LOSS ]) + sum([ nco[0] for nco in NONCODINGO_LOSS ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs LOSSES > 100kb in Cohort"+'\t'+repr(sum([ po[1] for po in PRIMARYO_LOSS ]) + sum([ so[1] for so in SECONDARYO_LOSS ]) + sum([ bo[1] for bo in BENIGNO_LOSS ]) + sum([ nco[1] for nco in NONCODINGO_LOSS ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs LOSSES > 500kb in Cohort"+'\t'+repr(sum([ po[2] for po in PRIMARYO_LOSS ]) + sum([ so[2] for so in SECONDARYO_LOSS ]) + sum([ bo[2] for bo in BENIGNO_LOSS ]) + sum([ nco[2] for nco in NONCODINGO_LOSS ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of CNVs LOSSES > 1Mb in Cohort"+'\t'+repr(sum([ po[3] for po in PRIMARYO_LOSS ]) + sum([ so[3] for so in SECONDARYO_LOSS ]) + sum([ bo[3] for bo in BENIGNO_LOSS ]) + sum([ nco[3] for nco in NONCODINGO_LOSS ]))+'\n')
 COMPLETE_OUTPUT.write('\n')

 # Write Average Number of CNVs by Length Group to File
 COMPLETE_OUTPUT.write("Average Number of CNVs > 50kb in Cohort"+'\t'+repr((sum([ po[0] for po in PRIMARYO ]) + sum([ so[0] for so in SECONDARYO ]) + sum([ bo[0] for bo in BENIGNO ]) + sum([ nco[0] for nco in NONCODINGO ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs > 100kb in Cohort"+'\t'+repr((sum([ po[1] for po in PRIMARYO ]) + sum([ so[1] for so in SECONDARYO ]) + sum([ bo[1] for bo in BENIGNO ]) + sum([ nco[1] for nco in NONCODINGO ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs > 500kb in Cohort"+'\t'+repr((sum([ po[2] for po in PRIMARYO ]) + sum([ so[2] for so in SECONDARYO ]) + sum([ bo[2] for bo in BENIGNO ]) + sum([ nco[2] for nco in NONCODINGO ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs > 1Mb in Cohort"+'\t'+repr((sum([ po[3] for po in PRIMARYO ]) + sum([ so[3] for so in SECONDARYO ]) + sum([ bo[3] for bo in BENIGNO ]) + sum([ nco[3] for nco in NONCODINGO ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs GAINS > 50kb in Cohort"+'\t'+repr((sum([ po[0] for po in PRIMARYO_GAIN ]) + sum([ so[0] for so in SECONDARYO_GAIN ]) + sum([ bo[0] for bo in BENIGNO_GAIN ]) + sum([ nco[0] for nco in NONCODINGO_GAIN ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs GAINS > 100kb in Cohort"+'\t'+repr((sum([ po[1] for po in PRIMARYO_GAIN ]) + sum([ so[1] for so in SECONDARYO_GAIN ]) + sum([ bo[1] for bo in BENIGNO_GAIN ]) + sum([ nco[1] for nco in NONCODINGO_GAIN ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs GAINS > 500kb in Cohort"+'\t'+repr((sum([ po[2] for po in PRIMARYO_GAIN ]) + sum([ so[2] for so in SECONDARYO_GAIN ]) + sum([ bo[2] for bo in BENIGNO_GAIN ]) + sum([ nco[2] for nco in NONCODINGO_GAIN ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs GAINS > 1Mb in Cohort"+'\t'+repr((sum([ po[3] for po in PRIMARYO_GAIN ]) + sum([ so[3] for so in SECONDARYO_GAIN ]) + sum([ bo[3] for bo in BENIGNO_GAIN ]) + sum([ nco[3] for nco in NONCODINGO_GAIN ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs LOSSES > 50kb in Cohort"+'\t'+repr((sum([ po[0] for po in PRIMARYO_LOSS ]) + sum([ so[0] for so in SECONDARYO_LOSS ]) + sum([ bo[0] for bo in BENIGNO_LOSS ]) + sum([ nco[0] for nco in NONCODINGO_LOSS ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs LOSSES > 100kb in Cohort"+'\t'+repr((sum([ po[1] for po in PRIMARYO_LOSS ]) + sum([ so[1] for so in SECONDARYO_LOSS ]) + sum([ bo[1] for bo in BENIGNO_LOSS ]) + sum([ nco[1] for nco in NONCODINGO_LOSS ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs LOSSES > 500kb in Cohort"+'\t'+repr((sum([ po[2] for po in PRIMARYO_LOSS ]) + sum([ so[2] for so in SECONDARYO_LOSS ]) + sum([ bo[2] for bo in BENIGNO_LOSS ]) + sum([ nco[2] for nco in NONCODINGO_LOSS ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of CNVs LOSSES > 1Mb in Cohort"+'\t'+repr((sum([ po[3] for po in PRIMARYO_LOSS ]) + sum([ so[3] for so in SECONDARYO_LOSS ]) + sum([ bo[3] for bo in BENIGNO_LOSS ]) + sum([ nco[3] for nco in NONCODINGO_LOSS ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write('\n')

 # Write Total Number of Non-Benign CNVs by Length Group to File
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs > 50kb in Cohort"+'\t'+repr(sum([ po[0] for po in PRIMARYO ]) + sum([ so[0] for so in SECONDARYO ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs > 100kb in Cohort"+'\t'+repr(sum([ po[1] for po in PRIMARYO ]) + sum([ so[1] for so in SECONDARYO ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs > 500kb in Cohort"+'\t'+repr(sum([ po[2] for po in PRIMARYO ]) + sum([ so[2] for so in SECONDARYO ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs > 1Mb in Cohort"+'\t'+repr(sum([ po[3] for po in PRIMARYO ]) + sum([ so[3] for so in SECONDARYO ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs GAINS > 50kb in Cohort"+'\t'+repr(sum([ po[0] for po in PRIMARYO_GAIN ]) + sum([ so[0] for so in SECONDARYO_GAIN ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs GAINS > 100kb in Cohort"+'\t'+repr(sum([ po[1] for po in PRIMARYO_GAIN ]) + sum([ so[1] for so in SECONDARYO_GAIN ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs GAINS > 500kb in Cohort"+'\t'+repr(sum([ po[2] for po in PRIMARYO_GAIN ]) + sum([ so[2] for so in SECONDARYO_GAIN ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs GAINS > 1Mb in Cohort"+'\t'+repr(sum([ po[3] for po in PRIMARYO_GAIN ]) + sum([ so[3] for so in SECONDARYO_GAIN ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs LOSSES > 50kb in Cohort"+'\t'+repr(sum([ po[0] for po in PRIMARYO_LOSS ]) + sum([ so[0] for so in SECONDARYO_LOSS ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs LOSSES > 100kb in Cohort"+'\t'+repr(sum([ po[1] for po in PRIMARYO_LOSS ]) + sum([ so[1] for so in SECONDARYO_LOSS ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs LOSSES > 500kb in Cohort"+'\t'+repr(sum([ po[2] for po in PRIMARYO_LOSS ]) + sum([ so[2] for so in SECONDARYO_LOSS ]))+'\n')
 COMPLETE_OUTPUT.write("Total Number of Non-Benign CNVs LOSSES > 1Mb in Cohort"+'\t'+repr(sum([ po[3] for po in PRIMARYO_LOSS ]) + sum([ so[3] for so in SECONDARYO_LOSS ]))+'\n')
 COMPLETE_OUTPUT.write('\n')

 # Write Average Number of Non-Benign CNVs per Person by Length Group to File
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs > 50kb per Patient"+'\t'+repr((sum([ po[0] for po in PRIMARYO ]) + sum([ so[0] for so in SECONDARYO ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs > 100kb per Patient"+'\t'+repr((sum([ po[1] for po in PRIMARYO ]) + sum([ so[1] for so in SECONDARYO ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs > 500kb per Patient"+'\t'+repr((sum([ po[2] for po in PRIMARYO ]) + sum([ so[2] for so in SECONDARYO ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs > 1Mb per Patient"+'\t'+repr((sum([ po[3] for po in PRIMARYO ]) + sum([ so[3] for so in SECONDARYO ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs GAINS > 50kb per Patient"+'\t'+repr((sum([ po[0] for po in PRIMARYO_GAIN ]) + sum([ so[0] for so in SECONDARYO_GAIN ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs GAINS > 100kb per Patient"+'\t'+repr((sum([ po[1] for po in PRIMARYO_GAIN ]) + sum([ so[1] for so in SECONDARYO_GAIN ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs GAINS > 500kb per Patient"+'\t'+repr((sum([ po[2] for po in PRIMARYO_GAIN ]) + sum([ so[2] for so in SECONDARYO_GAIN ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs GAINS > 1Mb per Patient"+'\t'+repr((sum([ po[3] for po in PRIMARYO_GAIN ]) + sum([ so[3] for so in SECONDARYO_GAIN ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs LOSSES > 50kb per Patient"+'\t'+repr((sum([ po[0] for po in PRIMARYO_LOSS ]) + sum([ so[0] for so in SECONDARYO_LOSS ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs LOSSES > 100kb per Patient"+'\t'+repr((sum([ po[1] for po in PRIMARYO_LOSS ]) + sum([ so[1] for so in SECONDARYO_LOSS ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs LOSSES > 500kb per Patient"+'\t'+repr((sum([ po[2] for po in PRIMARYO_LOSS ]) + sum([ so[2] for so in SECONDARYO_LOSS ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write("Average Number of Non-Benign CNVs LOSSES > 1Mb per Patient"+'\t'+repr((sum([ po[3] for po in PRIMARYO_LOSS ]) + sum([ so[3] for so in SECONDARYO_LOSS ]))/(len(PATIENT_DATA.keys())))+'\n')
 COMPLETE_OUTPUT.write('\n')

 COMPLETE_OUTPUT.write("Primary CNVs Detected"
   +'\t'+"Count of Primary CNV"
   +'\t'+"Total Number Co-Occuring Primary CNVs"
   +'\t'+"Number of Unique Co-Occuring Primary CNVs"
   +'\t'+"IDs of Unique Co-Occuring Primary CNVs"
   +'\t'+"Average Number Co-Occuring Secondary CNVs (across all patients with this Primary CNV)"
   +'\t'+"Total Number Co-Occuring Secondary CNVs (across all patients with this Primary CNV)"
   +'\t'+"Total Number Co-Occuring  Secondary GAIN CNVs (across all patients with this Primary CNV)"
   +'\t'+"Total Number Co-Occuring  Secondary LOSS CNVs (across all patients with this Primary CNV)"
   +'\t'+"Genes Present in Parent Primary GAIN CNV and Co-Occuring Primary GAIN CNVs (across all patients with this Primary CNV)"
   +'\t'+"Genes Present in Parent Primary LOSS CNV and Co-Occuring Primary LOSS CNVs (across all patients with this Primary CNV)"
   +'\t'+"Genes Present in Co-Occuring Secondary GAINS CNVs (across all patients with this Primary CNV)"
   +'\t'+"Genes Present in Co-Occuring Secondary LOSS CNVs (across all patients with this Primary CNV)"+'\n')


 # Loop over Primary CNV Gain/Loss Dictionary Twice to Look for Co-Occurring Primary CNVs
    # If Co-Occuring Primary CNVs Found
        # Add CNV-1 to Dictionary as Key; Co-Occurring CNV-2 as Value
        # Add CNV-1 to Dictionary as Key; Co-Occurring CNV-2 (with SampleID) as Value
    # Write Data to File
 COOCURRING_CNVS_DICT=defaultdict(list); COOCURRING_CNVS_CTR_DICT=defaultdict(list)

 # Get Frequency of Each Primary CNV
 PRIMARY_CTR = defaultdict(list)
 for pglA in PRIMARY_GL_DICT.keys(): PRIMARY_CTR[len(PRIMARY_GL_DICT[pglA])].append(pglA)

 # Order by Frequency of Primary CNV
 for a in sorted(PRIMARY_CTR, reverse=True):
   for each in PRIMARY_CTR[a]:
     pglA = each
     if pglA in PRIMARY_GL_DICT.keys():
       for pglB in PRIMARY_GL_DICT.keys():
         if pglA != pglB: # If Primary CNVs are Different
           PCNV1 = Counter(PRIMARY_GL_DICT[pglA]) # Primary CNV #1; Get Set of PatientID(s)
           PCNV2 = Counter(PRIMARY_GL_DICT[pglB]) # Primary CNV #2; Get Set of PatientID(s)
           OVERLAP = list(PCNV1&PCNV2) # Get Set of Patients with BOTH Primary CNVs
           if len(OVERLAP) > 0: 
             P = [ O +'_'+ i[5] for O in OVERLAP for i in PATIENT_DATA[O] if 'PRIMARY' in i and not pglA in i ] # SampleID+PrimaryCNV
             COOCURRING_CNVS_DICT[pglA].append(pglB) # Add Primary CNV #1 to Dictionary as Key; Primary CNV #2 as Value
             COOCURRING_CNVS_CTR_DICT[pglA].append(P) # Add Primary CNV #1 to Dictionary as Key; SampleID+PrimaryCNV as Value

     # Identify Genes for GAIN/LOSS Primary and Secondary CNVs
     GENES_PG=';'.join(sorted(list(set(';'.join([ ';'.join(GAIN_PRIMARY[i]) for i in PRIMARY_GL_DICT[pglA] if len(GAIN_PRIMARY[i]) > 0 ]).split(';'))))) # List of GAIN Genes in GAIN Primary CNV and GAIN Co-Occuring Primary CNVs (across all patients)
     GENES_PL=';'.join(sorted(list(set(';'.join([ ';'.join(LOSS_PRIMARY[i]) for i in PRIMARY_GL_DICT[pglA] if len(LOSS_PRIMARY[i]) > 0 ]).split(';'))))) # List of LOSS Genes in LOSS Primary CNV and LOSS Co-Occuring Primary CNVs (across all patients)
     GENES_SG=';'.join(sorted(list(set(';'.join([ ';'.join(GAIN_SECONDARY[i]) for i in PRIMARY_GL_DICT[pglA] if len(GAIN_SECONDARY[i]) > 0 ]).split(';'))))) # List of GAIN Genes in GAIN Secondary CNVs (across all patients)
     GENES_SL=';'.join(sorted(list(set(';'.join([ ';'.join(LOSS_SECONDARY[i]) for i in PRIMARY_GL_DICT[pglA] if len(LOSS_SECONDARY[i]) > 0 ]).split(';'))))) # List of LOSS Genes in LOSS Secondary CNVs (across all patients)

     # Get Data for COMPLETE_OUTPUT Table
     A = pglA +'\t'+ repr(len(PRIMARY_GL_DICT[pglA])) # Print Primary CNV & Count
     B = repr(len(list(set(sum(COOCURRING_CNVS_CTR_DICT[pglA],[]))))) # Total Co-Occurring CNVs
     C = repr(len(COOCURRING_CNVS_DICT[pglA])) # Total Unique Co-Occuring CNVs
     D = ';'.join(list(set(COOCURRING_CNVS_DICT[pglA]))) # IDs of Co-Occuring CNVs
     E = repr(COSECONDARY[pglA]/len(PRIMARY_GL_DICT[pglA])) # Average Number of Secondary CNVs
     F = repr(COSECONDARY[pglA]) # Total Number of Secondary CNVs
     G = repr(COSECONDARY_GAIN[pglA]) # Number of Secondary GAIN
     H = repr(COSECONDARY_LOSS[pglA]) # Number of Secondary LOSS

     OUT = '\t'.join([ A,B,C,D,E,F,G,H,GENES_PG,GENES_PL,GENES_SG,GENES_SL ]) # Join Columns
     TMP = '\t'.join([ '.' if len(i)<1 else i for i in OUT.split('\t') ]) # Replace EMPTY Column Value with 'NA'
     COMPLETE_OUTPUT.write(TMP+'\n') # Write to File

 sys.exit()
 COMPLETE_OUTPUT.close()

except KeyboardInterrupt:
 print ''
 sys.exit(1)
