# load required python modules
import os, sys, re, glob
from progress.bar import Bar
from collections import defaultdict
from intervaltree import Interval, IntervalTree

try:
 # Get List of Cohort File(s)
 PATH = os.path.dirname(os.path.realpath(__file__)).replace('/CODE','')
 COHRTF = filter(None, [ fil.strip() for fil in open(PATH.strip() + '/PARAMETERS/COHORT_FILES', 'r').readlines()])

 # Perform Pre-Processing on Cohort File
 print 'BUILDING PATIENT MERGED DATA FILES...'
 for ecf in COHRTF:
    COMMAND = 'python ' + PATH.strip() + '/CODE/PATIENT_DATA_MERGE.py ' + PATH.strip() + '/SOURCE_DATA/COHORTS/' + ecf.strip()
    if os.system(COMMAND) != 0: raise Exception

 # Merge Benign Regions Function
 def MERGEBENIGN(FILELIST, VER, CTR):
    OFILE = open(PATH.strip() + '/OUTPUT/BENIGN_MERGED_' + VER.strip() + '.txt', 'w') # Create Benign Interval File
    BDATAG = defaultdict(list); BDATAL = defaultdict(list)
    FAIL=[]

    # For Each Benign File
    for FILE in FILELIST:

        # IF GAIN File Found: Add Lines to BDATAG Dictionary with chrom as Key; Interval as Value
        if 'GAIN' in FILE:
            if os.path.isfile(FILE):
                for gline in open(FILE, 'r').readlines():
                    BDATAG[gline.strip().split('\t')[0].strip()].append([ int(i) for i in gline.strip().split('\t')[1:3] ])
            else:
                print '\n' + 'FILE NOT FOUND: ' + FILE
                sys.exit()

        # IF LOSS File Found: Add Lines to BDATAL Dictionary with chrom as Key; Interval as Value
        elif 'LOSS' in FILE:
            if os.path.isfile(FILE):
                for lline in open(FILE, 'r').readlines():
                    BDATAL[lline.strip().split('\t')[0].strip()].append([ int(i) for i in lline.strip().split('\t')[1:3] ])
            else:
                print '\n' + 'FILE NOT FOUND: ' + FILE
                sys.exit()

        # IF File Found: Add Lines to appropriate Dictionary (BDATAG or BDATAL) with chrom as Key; Interval as Value
        else: 
            if os.path.isfile(FILE):
                ctr=0
                for line in open(FILE, 'r').readlines():
                  try:
                    ctr+=1
                    if 'GAIN' in line.upper(): BDATAG[line.strip().split('\t')[0].strip()].append([ int(i) for i in line.strip().split('\t')[1:3] ])
                    elif 'LOSS' in line.upper(): BDATAL[line.strip().split('\t')[0].strip()].append([ int(i) for i in line.strip().split('\t')[1:3] ])
                    else: FAIL.append(ctr)
                  except ValueError:
                    FAIL.append(ctr)
            else:
                print '\n' + 'FILE NOT FOUND: ' + FILE
                sys.exit()

        if len(FAIL) > 0:
            print '\n',"THE FOLLOWING LINES OF BENIGN FILE ['"+FILE.strip().split('/')[-1]+"'] HAVE INCORRECT FORMATTING:",FAIL
            sys.exit()
        PROGRESS.next()

    # For BDATAG Dictionary; Merge Intervals
    for chrom in sorted(BDATAG.keys()):
        GREGION = BDATAG[chrom.strip()]
        GTREE = IntervalTree()

        # Add Intervals to Interval Tree
        for gregion in GREGION: GTREE.add(Interval( int(gregion[0]),int(gregion[1]) ))
        GTREE.merge_overlaps(strict=False)

        # Write Merged Intervals to File
        for gtree in sorted(GTREE): OFILE.write('\t'.join([chrom.strip(),'GAIN',repr(gtree[0]),repr(gtree[1])]) + '\n')
    PROGRESS.next()

    # For BDATAL Dictionary; Merge Intervals
    for chrom in sorted(BDATAL.keys()):
        LREGION = BDATAL[chrom.strip()]
        LTREE = IntervalTree()
        for lregion in LREGION: LTREE.add(Interval( int(lregion[0]),int(lregion[1]) ))
        LTREE.merge_overlaps(strict=False)
        for ltree in sorted(LTREE): OFILE.write('\t'.join([chrom.strip(),'LOSS',repr(ltree[0]),repr(ltree[1])]) + '\n')
    PROGRESS.next()
    OFILE.close()

 # Get List of Benign File(s)
 BFILES = open(PATH.strip() + '/PARAMETERS/BENIGN_FILES', 'r').readlines()
 GCTR=[];  r = re.compile("HG[0-9]")
 for BF in BFILES: 
    try:
      GENOME = filter(r.match, BF.strip().upper().split('_'))[0].split('.')[0]
      GCTR.append(GENOME)
    except IndexError:
      print '\n',"THE FOLLOWING BENIGN FILE ['"+BF.strip()+"'] IS MISSING GENOME INFORMATION IN FILENAME."
      sys.exit()   

 print '\nBUILDING BENIGN MERGED DATA FILES...'
 PROGRESS = Bar('   Processing', max=len(BFILES)*2+len(list(set(GCTR)))+2, suffix='%(percent)d%%')

 # Get Full File Path of Provided Benign Files; Save to BDICT with Genome Version as Value; File Path as Key
    # If Genome Version [HGXX] Not Provided use "NA" as Genome Version
 BDICT = defaultdict(list)
 r = re.compile("HG[0-9]")
 DIR = ['GAIN', 'LOSS']
 CTR=0
 for BF in BFILES:
    BFILE = PATH+'/SOURCE_DATA/BENIGN/'+BF.strip()
    BDICT[GENOME].append(BFILE)
    PROGRESS.next()

 # Loop Through Benign File(s); Merge
 for VER in BDICT.keys():
    MERGEBENIGN(BDICT[VER.strip()], VER.strip(), CTR)
    PROGRESS.next()
 PROGRESS.finish()

 print '\nASSIGNING PROVISIONAL PATHOGENICITY CLASSIFICATIONS'
 # Define DISCRIMINATOR Function
 def DISCRIMINATOR(PATIENTFILES,BENIGNFILES):
 
   PRIM_CNV=[PATH+'/SOURCE_DATA/PRIMARY/'+pcnv.strip() for pcnv in open(PATH.strip()+'/PARAMETERS/PRIMARY_CNV_FILES','r').readlines()] # Get List of Primary CNVs Files
   JACCARD_INDEX=[jdex.strip() for jdex in open(PATH.strip()+'/PARAMETERS/JACCARD_INDEX','r').readlines()] # Get List of Jaccard Index Values

   # For Each Combination of { Patient File + Benign File + Primary CNV File + Jaccard Index }; Run DISCRIMINATOR_ALG Script
   for PF in PATIENTFILES:
     for BF in BENIGNFILES:
       for PCNV in PRIM_CNV:
         for JI in JACCARD_INDEX:
           GENOME = filter(r.match, BF.strip().upper().split('_'))[0].replace('.TXT','')
           COMMAND = 'python ' + PATH.strip() + '/CODE/DISCRIMINATOR_ALG.py ' + PF + ' ' + BF + ' ' + PCNV + ' ' + JI + ' ' + GENOME
           if os.system(COMMAND) != 0: raise Exception
           COMMAND = 'python ' + PATH.strip() + '/CODE/STATISTICS_AND_OUTPUT.py ' + PF + ' ' + BF + ' ' + PCNV + ' ' + JI
           if os.system(COMMAND) != 0: raise Exception

 # Get List of MERGED Benign & Patient Files
 BENIGNFILES = glob.glob(PATH.strip() + '/OUTPUT/BENIGN_MERGED*')
 PATIENTFILES = glob.glob(PATH.strip() + '/OUTPUT/*_MERGED.txt')
 PATIENTFILES = [ PF.strip() for PF in PATIENTFILES for CF in COHRTF if CF.strip().upper().replace('.TXT','') in PF.strip().upper() ]

 # Run DISCRIMINATOR
 DISCRIMINATOR(PATIENTFILES,BENIGNFILES)

except:
  print '\n\nERROR: DISCRIMINATOR RUN CANCELLED.'
  sys.exit()
