#! /bin/bash

#CHECK FOR INPUT FILE PATH
if [ $# -ne 2 ]; then
    echo "./DISCRIMINATOR_PreProcessing.sh INPUT OUTPUT"
    exit 1
fi

INPUT="$1"
OUTPUT="$2"
PTH=$(dirname $0)
echo -e "chr22\t20249559\t20744436\t22q11.2_AB:BD" > 22q11.2_AB_BD.bed

# Modify Input File Format
tr -d $'\r' < $PTH/DATA/50kbsegdups.bed > temp && mv temp 50kbsegdups.bed
tr -d $'\r' < $PTH/DATA/PrimaryCNVs.bed > temp && mv temp PrimaryCNVs.bed
tr -d $'\r' < $INPUT > temmmppp && mv temmmppp $INPUT


# Create Progress Bar
function ProgressBar {
    let _progress=(${1}*100/${2}*100)/100
    let _done=(${_progress}*4)/10
    let _left=40-$_done
    _fill=$(printf "%${_done}s")
    _empty=$(printf "%${_left}s")
printf "\rProgress : [${_fill// /#}${_empty// /-}] ${_progress}%%"
}
i=0
_end=11

#############################
# Merge CNVs if <30kb apart #
#############################
echo -e "Merging Patient CNVs...."

sed 's/ /_/g' $INPUT | awk -v OFS="\t" -F'[\t:-]' 'NR>1{print $2"|"$1"|"$5, $3, $4 }' |
	bedtools sort | bedtools merge -d 30000 | 
	sed 's/|/\t/g' | awk -v OFS="\t" '{print $1, $4, $5, $2"|"$3}' > input.bed
((i=i+1))
ProgressBar ${i} ${_end}

###############################################################################
# Process CNVs that need to be merged in 1q21.1, 15q11.2, and 22q11.2 regions #
###############################################################################
# Get CNVs to Merge:
    # Overlaps 1q21.1, 15q11.2, or 22q11.2 Region
    # NOT 100% Overlapped by 50kb SegDup Cluster
    # 2+ CNVs for Each Person/Direction/Primary CNV Less than 1 MB Apart
bedtools sort -i input.bed | 
	bedtools intersect -wa -wb -a stdin -b PrimaryCNVs.bed | 
	bedtools intersect -wa -wb -a stdin -b 50kbsegdups.bed -f 1.0 -v | 
	awk -v OFS="\t" '{ print $1, $2, $3, $4, $8, $4"|"$8}' |
	awk -v OFS="\t" 'BEGIN {FS="\t"} {count[$6]++; if(count[$6]==1) first[$6]=$0; if(count[$6]==2) print first[$6]; if(count[$6]>1) print }' |
	bedtools sort -i | sort -k4,4 | awk -v OFS="\t" '{ print $0, NR }' |
	awk -v OFS="\t" '{ if($6==prev6) $8=$2-prev3; prev3=$3; prev6=$6; print }' |
	awk -v OFS="\t" '{ if($6!=prev6) $8="."; prev6=$6; print }' |
	awk -v OFS="\t" '{ if($8>1 && $8<1000000) {$9="MERGE"; print} else {$9="."; print} }' |
	grep -B 1 "MERGE" | grep "chr" | sort | uniq | sort -k7,7n | awk -v OFS="\t" '{ print $1, $2, $3, $6}' > PrimaryMerging.bed
((i=i+1))
ProgressBar ${i} ${_end}

# Merge If Region Between CNVs is >90% Covered by SegDups
awk '{key=$0; getline; print key,$0}' PrimaryMerging.bed | awk -v OFS="\t" '{ if($4==$8 && $2!=$6) print $1, $3, $6, $4"*"$1"|"$2"|"$3"*"$5"|"$6"|"$7}' > Regions.bed
awk 'NR>1{key=$0; getline; print key,$0}' PrimaryMerging.bed | awk -v OFS="\t" '{ if($4==$8 && $2!=$6) print $1, $3, $6, $4"*"$1"|"$2"|"$3"*"$5"|"$6"|"$7}' >> Regions.bed
bedtools sort -i Regions.bed |
	bedtools intersect -wa -wb -a stdin -b 50kbsegdups.bed -f 0.9 |
	awk '{ print $4 }' | awk -v OFS="\t" -F'[*|]' '{ print $1"|"$2"|"$3, $4, $5, $6"\n"$1"|"$2"|"$3, $7, $8, $9}' > MERGED
sort -k1,1 -k3,3n MERGED | awk -v OFS="\t" '!a[$1] {a[$1]=$3} $3 == a[$1] { print $1, $2, $3 }' > START
sort -k1,1 -k4,4gr MERGED | awk -v OFS="\t" '!a[$1] {a[$1]=$4} $4 == a[$1] { print $1, $4 }' > END
join START END -t $'\t' > 90SEGDUP
rm START END MERGED

bedtools sort -i Regions.bed |
	bedtools intersect -wa -wb -a stdin -b 50kbsegdups.bed -f 0.9 |
	awk '{ print $4 }' | awk -v OFS="\t" -F'[*|]' '{ print $1"|"$2"|"$3, $4, $5, $6"\n"$1"|"$2"|"$3, $7, $8, $9}' | sort | uniq > MERGED

# Add 90% SegDup Regions Back to File
bedtools sort -i Regions.bed |
	bedtools intersect -wa -wb -a stdin -b 50kbsegdups.bed -f 0.9 -v | 
	awk '{ print $4 }' | awk -v OFS="\t" -F'[*|]' '{ print $1"|"$2"|"$3, $4, $5, $6"\n"$1"|"$2"|"$3, $7, $8, $9}' | 
	sort | uniq | grep -vf MERGED - | cat 90SEGDUP - |
	awk -v OFS="\t" '{print $2, $3, $4, $1}' | 
	bedtools sort | sort -k 4,4 > 90SegDupMerged.bed
rm MERGED 90SEGDUP

((i=i+1))
ProgressBar ${i} ${_end}


# Merge if Region is 90% Overlapped by 22q11.2 "B" Breakpoint Region
awk '{key=$0; getline; print key,$0}' 90SegDupMerged.bed | awk -v OFS="\t" '{ if($4==$8 && $2!=$6) print $1, $3, $6, $4"*"$1"|"$2"|"$3"*"$5"|"$6"|"$7}' > Regions.bed
awk 'NR>1{key=$0; getline; print key,$0}' 90SegDupMerged.bed | awk -v OFS="\t" '{ if($4==$8 && $2!=$6) print $1, $3, $6, $4"*"$1"|"$2"|"$3"*"$5"|"$6"|"$7}' >> Regions.bed
awk -v OFS="\t" '{print $4, $1, $2, $3}' 90SegDupMerged.bed | sort | uniq > ALL

bedtools sort -i Regions.bed |
	bedtools intersect -wa -wb -a stdin -b 22q11.2_AB_BD.bed -f 0.9 |
	awk '{ print $4 }' | awk -v OFS="\t" -F'[*|]' '{ print $1"|"$2"|"$3, $4, $5, $6"\n"$1"|"$2"|"$3, $7, $8, $9}' > MERGED
sort -k1,1 -k3,3n MERGED | awk -v OFS="\t" '!a[$1] {a[$1]=$3} $3 == a[$1] { print $1, $2, $3 }' > START
sort -k1,1 -k4,4gr MERGED | awk -v OFS="\t" '!a[$1] {a[$1]=$4} $4 == a[$1] { print $1, $4 }' > END
join START END -t $'\t' > 22QBD
rm START END MERGED

bedtools sort -i Regions.bed |
	bedtools intersect -wa -wb -a stdin -b 22q11.2_AB_BD.bed -f 0.9 |
	awk '{ print $4 }' | awk -v OFS="\t" -F'[*|]' '{ print $1"|"$2"|"$3, $4, $5, $6"\n"$1"|"$2"|"$3, $7, $8, $9}' | sort | uniq > MERGED

# Add Non-22q11.2 "B" Breakpoint Regions Back to File
bedtools sort -i Regions.bed |
	bedtools intersect -wa -wb -a stdin -b 22q11.2_AB_BD.bed -f 0.9 -v |
	awk '{ print $4 }' | awk -v OFS="\t" -F'[*|]' '{ print $1"|"$2"|"$3, $4, $5, $6"\n"$1"|"$2"|"$3, $7, $8, $9}' |
	sort | uniq | grep -vf MERGED - > NOTMERGE
grep -vf MERGED ALL | grep -vf NOTMERGE - > SINGLETON
cat 22QBD NOTMERGE SINGLETON > 22QBDMerged.bed
rm 22QBD NOTMERGE SINGLETON MERGED ALL

((i=i+1))
ProgressBar ${i} ${_end}


# Merge if Region Between CNVs is <100kb
awk -v OFS="\t" '{ print $1"|"$2, $3, $4 }' 22QBDMerged.bed |
	bedtools sort | bedtools merge -d 100000 |
	awk -v OFS="\t" -F'[\t|]' '{print $4, $5, $6, $1"|"$2}' > FinalMerged.bed

((i=i+1))
ProgressBar ${i} ${_end}


###########################################
# Process CNVs which are NOT being merged #
###########################################
# Remove CNVs that DO NOT Overlap 1q21.1, 15q11.2, or 22q11.2 Regions
bedtools sort -i input.bed | 
	bedtools intersect -wa -wb -a stdin -b PrimaryCNVs.bed -v > NonPrimaryOverlapping.bed
((i=i+1))
ProgressBar ${i} ${_end}

# Remove CNVs that are 100% Overlapped by 50kb SegDup Clusters
bedtools sort -i input.bed |
	bedtools intersect -wa -wb -a stdin -b PrimaryCNVs.bed | 
	bedtools intersect -wa -wb -a stdin -b 50kbsegdups.bed -f 1.0 -u |
	awk -v OFS="\t" '{print $1, $2, $3, $4}' >> NonPrimaryOverlapping.bed
((i=i+1))
ProgressBar ${i} ${_end}

# Remove CNVs if there is only a single CNV for Each Region (Nothing to Be Merged)
bedtools sort -i input.bed |
	bedtools intersect -wa -wb -a stdin -b PrimaryCNVs.bed | 
	bedtools intersect -wa -wb -a stdin -b 50kbsegdups.bed -f 1.0 -v | 
	awk -v OFS="\t" '{ print $1, $2, $3, $4, $8, $4"|"$8}' |
	awk -v OFS="\t" '{++C[$6]; T[$6]=$0} END { for (t in T) if (C[t]==1) print T[t]}' |
	awk -v OFS="\t" '{print $1, $2, $3, $4}' >> NonPrimaryOverlapping.bed
((i=i+1))
ProgressBar ${i} ${_end}

# Remove CNVs if they are Greater than 1MB apart
bedtools sort -i input.bed | 
	bedtools intersect -wa -wb -a stdin -b PrimaryCNVs.bed | 
	bedtools intersect -wa -wb -a stdin -b 50kbsegdups.bed -f 1.0 -v | 
	awk -v OFS="\t" '{ print $1, $2, $3, $4, $8, $4"|"$8}' |
	awk -v OFS="\t" 'BEGIN {FS="\t"} {count[$6]++; if(count[$6]==1) first[$6]=$0; if(count[$6]==2) print first[$6]; if(count[$6]>1) print }' |
	bedtools sort -i | sort -k4,4 | awk -v OFS="\t" '{ print $1, $2, $3, $6}' > 1MB
grep -vf PrimaryMerging.bed 1MB >> NonPrimaryOverlapping.bed
rm 1MB

((i=i+1))
ProgressBar ${i} ${_end}


################################
# Final Formatting Adjustments #
################################
echo -e "Sample\tChromosome Region\tEvent" > $OUTPUT
cat NonPrimaryOverlapping.bed FinalMerged.bed |
	awk -F'[\t|]' -v OFS="\t" '{ print $1, $2, $3, $4, $5 }' | sort -k2,2n -k3,3n | sort -V -k4 -k5 -k1 |
	awk -v OFS="\t" '{ print $4, $1":"$2"-"$3, $5 }' >> $OUTPUT

((i=i+1))
ProgressBar ${i} ${_end}

##########################
# Remove temporary files #
##########################
rm NonPrimaryOverlapping.bed input.bed 90SegDupMerged.bed PrimaryMerging.bed Regions.bed 22QBDMerged.bed FinalMerged.bed
rm 22q11.2_AB_BD.bed 50kbsegdups.bed PrimaryCNVs.bed

((i=i+1))
ProgressBar ${i} ${_end}


echo ''
